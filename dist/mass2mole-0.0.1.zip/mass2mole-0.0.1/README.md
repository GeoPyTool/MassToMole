# MassToMole
A tool to calculate from mass percetange to mole percentage.
